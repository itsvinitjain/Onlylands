# MongoDB Atlas Setup Guide for OnlyLands

## 🗄️ Connecting EC2 to MongoDB Atlas

Your OnlyLands application on EC2 (51.21.198.121) needs to connect to MongoDB Atlas. Here's the complete setup:

### 📋 **Your Current Configuration**
- **EC2 Server:** 51.21.198.121 (Mumbai, ap-south-1)
- **Cluster:** cluster0.nwizwpq.mongodb.net
- **Database:** onlylands_db
- **Username:** onlylands
- **Connection:** mongodb+srv://onlylands:PASSWORD@cluster0.nwizwpq.mongodb.net/

---

## 🚀 **Step 1: Configure MongoDB Atlas**

### **1.1 Login to MongoDB Atlas**
1. Go to **https://cloud.mongodb.com**
2. **Login** with your account credentials
3. **Select your project** (or create one if needed)

### **1.2 Configure Database User**
1. **Left Sidebar** → **Database Access**
2. **Find user "onlylands"** or **Add New Database User**
   ```
   Username: onlylands
   Password: [Generate or set a secure password]
   Database User Privileges: Read and write to any database
   ```
3. **SAVE THE PASSWORD** - you'll need it!

### **1.3 Configure Network Access**
1. **Left Sidebar** → **Network Access**
2. **Add IP Address** → **Add Current IP Address**
3. **Manually add:** `51.21.198.121/32` (your EC2 server)
4. **Description:** "OnlyLands EC2 Server (Mumbai)"

**Alternative (Less Secure):** Add `0.0.0.0/0` to allow all IPs temporarily

### **1.4 Get Connection String**
1. **Left Sidebar** → **Database** → **Connect**
2. **Choose:** "Connect your application"
3. **Driver:** Python
4. **Copy the connection string:** 
   ```
   mongodb+srv://onlylands:<password>@cluster0.nwizwpq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
   ```

---

## 🔧 **Step 2: Update EC2 Backend Configuration**

### **2.1 Update Environment File**
```bash
# Connect to your EC2 server
ssh -i your-key.pem ubuntu@51.21.198.121
sudo su -

# Edit the backend environment file
nano /var/www/onlylands/backend/.env

# Update this line with your actual password:
MONGO_URL="mongodb+srv://onlylands:YOUR_ACTUAL_PASSWORD@cluster0.nwizwpq.mongodb.net/onlylands_db?retryWrites=true&w=majority&appName=Cluster0"
```

### **2.2 Test MongoDB Connection**
```bash
# Run the connection test script
/root/test-mongodb-atlas.sh

# Or test manually:
cd /var/www/onlylands/backend
source venv/bin/activate
python3 -c "
from pymongo import MongoClient
from dotenv import load_dotenv
import os
load_dotenv()
client = MongoClient(os.getenv('MONGO_URL'))
print('✅ Connected:', client.admin.command('ping'))
print('📊 Database:', client.onlylands_db.name)
"
```

### **2.3 Restart Backend Service**
```bash
# Restart the backend to apply new configuration
pm2 restart onlylands-backend

# Check if backend is healthy
curl http://localhost:8001/api/health

# View backend logs
pm2 logs onlylands-backend
```

---

## 🔍 **Step 3: Verify Connection**

### **3.1 Health Check Endpoints**
```bash
# Test basic health
curl http://localhost:8001/health

# Test database health  
curl http://localhost:8001/api/health
```

**Expected Response:**
```json
{
  "status": "healthy",
  "service": "onlylands-api",
  "database": "connected",
  "collections": 0,
  "timestamp": "2025-01-06T12:00:00.000Z"
}
```

### **3.2 Test Complete Application**
```bash
# Check all services
/root/check-status.sh

# Test API documentation
curl https://api.onlylands.in/docs
```

---

## 🐛 **Troubleshooting Common Issues**

### **Issue 1: Authentication Failed**
```
Error: Authentication failed
```
**Solution:**
- Double-check username/password in Atlas
- Verify connection string in .env file
- Reset password in Atlas and update .env

### **Issue 2: Network Timeout**
```
Error: ServerSelectionTimeoutError
```
**Solution:**
- Add EC2 IP (51.21.198.121) to Atlas Network Access
- Check EC2 security group allows outbound connections
- Verify cluster is running in Atlas

### **Issue 3: DNS Resolution**
```
Error: Name or service not known
```
**Solution:**
- Check internet connectivity: `ping 8.8.8.8`
- Verify DNS: `nslookup cluster0.nwizwpq.mongodb.net`
- Update /etc/resolv.conf if needed

### **Issue 4: SSL/TLS Issues**
```
Error: SSL certificate verify failed
```
**Solution:**
- Update system certificates: `apt update && apt install ca-certificates`
- Use the latest pymongo version (already in requirements.txt)

---

## 📊 **Database Collections Structure**

Your OnlyLands app will create these collections automatically:

```javascript
// users - User authentication and profiles
{
  "user_id": "uuid",
  "phone": "+91...",
  "user_type": "seller|broker",
  "name": "...",
  "created_at": "datetime"
}

// listings - Land listings
{
  "listing_id": "uuid", 
  "seller_id": "uuid",
  "title": "...",
  "location": "...",
  "price": "...",
  "images": [{"s3_url": "...", "content_type": "..."}],
  "status": "pending_payment|active",
  "created_at": "datetime"
}

// brokers - Broker registrations
{
  "broker_id": "uuid",
  "name": "...",
  "agency": "...",
  "phone": "...",
  "email": "...",
  "created_at": "datetime"
}

// payments - Payment records
{
  "payment_id": "uuid",
  "listing_id": "uuid", 
  "razorpay_order_id": "...",
  "status": "paid|pending",
  "amount": 29900,
  "created_at": "datetime"
}

// notifications - WhatsApp broadcast logs
{
  "notification_id": "uuid",
  "listing_id": "uuid",
  "type": "whatsapp_broadcast",
  "status": "sent|failed",
  "created_at": "datetime"
}
```

---

## 💰 **MongoDB Atlas Pricing**

### **Free Tier (M0)**
- **Storage:** 512MB
- **Cost:** $0/month
- **Good for:** Development and testing

### **Shared Tier (M2) - Recommended**
- **Storage:** 2GB
- **Cost:** $9/month
- **Good for:** Production with moderate usage

### **Dedicated Tier (M10)**
- **Storage:** 10GB  
- **Cost:** $57/month
- **Good for:** High-traffic production

**Recommendation:** Start with M2 ($9/month) for production

---

## 🔄 **Backup and Monitoring**

### **Automatic Backups** (Atlas Feature)
- **M2 and above:** Continuous backups included
- **Retention:** 7 days (configurable)
- **Point-in-time recovery:** Available

### **Monitoring** (Atlas Dashboard)
- **Real-time metrics:** CPU, Memory, Connections
- **Query performance:** Slow query analysis
- **Alerts:** Set up email/SMS alerts for issues

### **Manual Backup** (Optional)
```bash
# Create manual backup on EC2
mongodump --uri="mongodb+srv://onlylands:PASSWORD@cluster0.nwizwpq.mongodb.net/onlylands_db"

# Upload to S3
aws s3 cp dump/ s3://onlyland/backups/ --recursive
```

---

## ✅ **Final Checklist**

- [ ] MongoDB Atlas account configured
- [ ] Database user "onlylands" created with password
- [ ] EC2 IP (51.21.198.121) added to Network Access
- [ ] Connection string updated in /var/www/onlylands/backend/.env
- [ ] Backend restarted with pm2 restart onlylands-backend
- [ ] Health check returns "database": "connected"
- [ ] Application accessible at https://onlylands.in

---

## 🆘 **Emergency Contacts**

If you need help:
1. **MongoDB Atlas Support:** Available 24/7 for paid tiers
2. **Community:** MongoDB Community Forums
3. **AWS Support:** For EC2 connectivity issues

**Your total monthly cost:** EC2 ($17) + MongoDB Atlas M2 ($9) = **$26/month**

---

**🎉 Once configured, your OnlyLands application will have a professional, scalable database solution hosted on MongoDB Atlas!**
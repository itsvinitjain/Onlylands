#!/bin/bash

# MongoDB Atlas Connection Test Script
# Run this to test your MongoDB Atlas connection

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}==== $1 ====${NC}"
}

print_header "MongoDB Atlas Connection Test"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "Please run this script as root (use sudo su -)"
    exit 1
fi

APP_DIR="/var/www/onlylands/backend"

# Check if .env file exists
if [ ! -f "$APP_DIR/.env" ]; then
    print_error ".env file not found at $APP_DIR/.env"
    print_error "Please run the deployment script first"
    exit 1
fi

print_status "Reading MongoDB connection string from .env..."

# Extract MongoDB URL from .env file
MONGO_URL=$(grep "MONGO_URL=" $APP_DIR/.env | cut -d'"' -f2)

if [[ $MONGO_URL == *"YOUR_DB_PASSWORD"* ]]; then
    print_error "MongoDB password not updated in .env file"
    print_warning "Please update YOUR_DB_PASSWORD with actual password in:"
    echo "nano $APP_DIR/.env"
    exit 1
fi

print_status "MongoDB URL configured (password hidden)"

# Navigate to backend directory
cd $APP_DIR

# Activate virtual environment
if [ -d "venv" ]; then
    source venv/bin/activate
    print_status "Virtual environment activated"
else
    print_error "Virtual environment not found. Please run deployment first."
    exit 1
fi

# Test MongoDB connection with Python
print_status "Testing MongoDB Atlas connection..."

cat > test_mongo.py << 'EOF'
import os
import sys
from pymongo import MongoClient
from dotenv import load_dotenv
from datetime import datetime

# Load environment variables
load_dotenv()

try:
    # Get connection string
    MONGO_URL = os.getenv("MONGO_URL")
    DB_NAME = os.getenv("DB_NAME", "onlylands_db")
    
    print(f"🔗 Connecting to MongoDB Atlas...")
    print(f"📊 Database: {DB_NAME}")
    print(f"🔗 URL: {MONGO_URL[:50]}...")
    
    # Create connection
    client = MongoClient(
        MONGO_URL,
        serverSelectionTimeoutMS=5000,
        connectTimeoutMS=10000,
        socketTimeoutMS=20000,
        retryWrites=True,
        w='majority'
    )
    
    # Test connection
    print("🔄 Testing connection...")
    result = client.admin.command('ping')
    print("✅ Connection successful!")
    
    # Get database
    db = client[DB_NAME]
    
    # List collections
    collections = db.list_collection_names()
    print(f"📋 Collections found: {len(collections)}")
    if collections:
        for collection in collections:
            count = db[collection].count_documents({})
            print(f"  - {collection}: {count} documents")
    else:
        print("  - No collections found (this is normal for new database)")
    
    # Test write operation
    test_collection = db.connection_test
    test_doc = {
        "test": True,
        "timestamp": datetime.utcnow(),
        "server": "EC2-Mumbai",
        "app": "OnlyLands"
    }
    
    print("🔄 Testing write operation...")
    result = test_collection.insert_one(test_doc)
    print(f"✅ Write successful! Document ID: {result.inserted_id}")
    
    # Clean up test document
    test_collection.delete_one({"_id": result.inserted_id})
    print("🧹 Test document cleaned up")
    
    print("")
    print("🎉 MongoDB Atlas connection is working perfectly!")
    print("")
    print("✅ Connection: OK")
    print("✅ Authentication: OK") 
    print("✅ Read Operations: OK")
    print("✅ Write Operations: OK")
    print("✅ Database Access: OK")
    
    client.close()
    
except Exception as e:
    print(f"❌ MongoDB connection failed: {str(e)}")
    print("")
    print("🔧 Troubleshooting:")
    print("1. Check if password is correct in .env file")
    print("2. Verify IP whitelist in MongoDB Atlas Network Access")
    print("3. Ensure cluster is running in MongoDB Atlas")
    print("4. Check internet connectivity from EC2")
    
    sys.exit(1)
EOF

# Run the test
python3 test_mongo.py

# Clean up test file
rm -f test_mongo.py

print_header "MongoDB Atlas Status Summary"

if [ $? -eq 0 ]; then
    print_status "🎉 MongoDB Atlas is properly configured!"
    print_status "Your OnlyLands app can now use the database"
    echo ""
    print_status "Next steps:"
    echo "1. Start/restart your backend: pm2 restart onlylands-backend"
    echo "2. Check backend health: curl http://localhost:8001/api/health"
    echo "3. Test your application: https://onlylands.in"
else
    print_error "❌ MongoDB Atlas connection failed"
    print_warning "Please check the troubleshooting steps above"
fi